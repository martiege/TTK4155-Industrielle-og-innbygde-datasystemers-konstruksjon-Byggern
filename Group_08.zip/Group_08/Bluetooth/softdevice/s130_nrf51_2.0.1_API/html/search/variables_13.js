var searchData=
[
  ['unit',['unit',['../structble__gatts__char__pf__t.html#ab28e4dc2a48e6329df85b3f974cf4466',1,'ble_gatts_char_pf_t']]],
  ['update',['update',['../structble__gatts__authorize__params__t.html#a4216f6db5f93262ffd447ca9b4524646',1,'ble_gatts_authorize_params_t']]],
  ['user_5fdesc_5fhandle',['user_desc_handle',['../structble__gatts__char__handles__t.html#a263781c226cad6bfeeb894e133b19c55',1,'ble_gatts_char_handles_t']]],
  ['user_5fmem_5frelease',['user_mem_release',['../structble__common__evt__t.html#a21a25a889c763bceb2891d506331f484',1,'ble_common_evt_t']]],
  ['user_5fmem_5frequest',['user_mem_request',['../structble__common__evt__t.html#a4d36c1c20a1ff24a62abba8ea73c74c8',1,'ble_common_evt_t']]],
  ['uuid',['uuid',['../structble__gattc__service__t.html#a3f00e5eb4b0f87085de2ea1e9464258b',1,'ble_gattc_service_t::uuid()'],['../structble__gattc__char__t.html#a69ac665a39feea71fafac8a54ecf0a5e',1,'ble_gattc_char_t::uuid()'],['../structble__gattc__desc__t.html#a039854704d107784b185fb11b00b1258',1,'ble_gattc_desc_t::uuid()'],['../structble__gatts__evt__write__t.html#a6db9d7b0d55f3942429b56729814e3a7',1,'ble_gatts_evt_write_t::uuid()'],['../structble__gatts__evt__read__t.html#a0f46ec246ade2872b88c0e02418808fa',1,'ble_gatts_evt_read_t::uuid()'],['../structble__uuid__t.html#ac9ccd46e82b1b51d561f17d49282348c',1,'ble_uuid_t::uuid()']]],
  ['uuid128',['uuid128',['../structble__gattc__attr__info__t.html#accd68e3b747b3e1d109f62880e469e9b',1,'ble_gattc_attr_info_t::uuid128()'],['../structble__uuid128__t.html#a6996185349442be9de548fd646efa972',1,'ble_uuid128_t::uuid128()']]],
  ['uuid16',['uuid16',['../structble__gattc__attr__info__t.html#a84ec34f460ea631bd723fde3fed22058',1,'ble_gattc_attr_info_t']]]
];
