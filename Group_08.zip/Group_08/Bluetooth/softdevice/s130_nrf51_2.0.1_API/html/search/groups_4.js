var searchData=
[
  ['events_2c_20type_20definitions_20and_20api_20calls',['Events, type definitions and API calls',['../group__ble__api.html',1,'']]],
  ['enumerations',['Enumerations',['../group__BLE__COMMON__ENUMERATIONS.html',1,'']]],
  ['enumerations',['Enumerations',['../group__BLE__GAP__ENUMERATIONS.html',1,'']]],
  ['enumerations',['Enumerations',['../group__BLE__GATTC__ENUMERATIONS.html',1,'']]],
  ['enumerations',['Enumerations',['../group__BLE__GATTS__ENUMERATIONS.html',1,'']]],
  ['enumerations',['Enumerations',['../group__BLE__L2CAP__ENUMERATIONS.html',1,'']]],
  ['error_20codes_20base_20number_20definitions',['Error Codes Base number definitions',['../group__NRF__ERRORS__BASE.html',1,'']]],
  ['enumerations',['Enumerations',['../group__NRF__MBR__ENUMS.html',1,'']]],
  ['enumerations',['Enumerations',['../group__NRF__SDM__ENUMS.html',1,'']]],
  ['enumerations',['Enumerations',['../group__NRF__SOC__ENUMS.html',1,'']]]
];
