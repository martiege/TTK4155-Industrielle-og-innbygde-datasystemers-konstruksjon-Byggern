var searchData=
[
  ['types_20of_20uuid',['Types of UUID',['../group__BLE__UUID__TYPES.html',1,'']]],
  ['types',['Types',['../group__NRF__MBR__TYPES.html',1,'']]],
  ['types',['Types',['../group__NRF__SDM__TYPES.html',1,'']]]
];
